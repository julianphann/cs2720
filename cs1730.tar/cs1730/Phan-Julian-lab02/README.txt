To compile lab02.c, the given makefile provides commands to perform necessary s$
$ make

To run the program use the command:
$ ./lab02

To remove the compiled executable use the command:
$ make clean
