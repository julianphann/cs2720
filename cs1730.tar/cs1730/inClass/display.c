#include <stdio.h>

int main()
{
  int name=Julian;
  int age=25;
  int height=157.48;
  char faveCharacter=j;

  printf("Name=", name);
  printf("Age= %d\n", age);
  printf("Height= %d\n", height);
  printf("Favorite Character= %c\n", faveCharacter);
}
